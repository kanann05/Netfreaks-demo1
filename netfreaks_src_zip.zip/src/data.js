const data = [
    {
        ep: "6",
        epn: "the witness",
        src : "https://droxonwave.site/file2/m~yjTrxD9jSgeFrHJbx9qTsq3Nq~zE7BU2y5dJ+qqlxe3JcQGBxsBnkiYZwR4qi8Ofq9DOp01xM2vOKdHP+Y57~qogDwsFchlFxR0dwLsbkRDDNpGb~DvR8UF6dFeUCSwaDMd7qcqRnHDW6S8~+l8nf7bxIz+rsu4bYK5epCr7w=/NzIw/aW5kZXgubTN1OA==.m3u8"
        ,sub : "./subs/6.vtt"
    },
    {
        ep: "7",
        epn: "i know you",
        src : "https://zeltroncloud66.pro/file2/FIl8R+0dNst31NA9UrVYhabNu0R4eyaN2OAdp+AzRe8aj~HmngPOrF3vaEDsFxBdq5TKFqHPl~x9NHBpU~h5FSug~4sI5crrI6UPuFVPnkTKR5yOovzHYNJoeQkm6mJplyCUDIuDi4Px~D4QBgwjzPLqP+TbyUi6ajsq0TagIKk=/NzIw/aW5kZXgubTN1OA==.m3u8"
        ,sub : "./subs/7.vtt"
    },
    {
        ep: "8  ",
        epn: "reinvestigation",
        src : "https://xelvornwave36.pro/file2/tiBwss72SRwigFljR1Vs0hhxCzXUQJyj1vFE9hnPcPJOpfkeNdk4c+vMrnd4O3ZT~jUBFjxn2kcF66M1qWdfmFvUqAE3CpqPCG6mIggjuogy4~GP42hXoDPzGS3eB7d2Hx48KYrBHYdxpuCPCXG~EJ4NyKc7zUBF9asyVf9SsQQ=/NzIw/aW5kZXgubTN1OA==.m3u8"
        ,sub : "./subs/8.vtt"
    },
    {
        ep: "9",
        epn: "i'll find the accomplice",
        src : "https://xelvornwave36.pro/file2/bkTehrvMBEQn5zG9Z6ywbHbA6ys1IFQwLqsLjWP2DcgtaJkDZhrA~lgef~N+TvNYtHCLZ8jhEzH1usuzq+tzYk0z7T2ZqCamszyvuc2xBrbgkIJ~EQ8V5jGdn5lJFzlPp2yIoVnP89ujPNVmxxFGVYob7lWyXt71msn4YGcSMm4=/NzIw/aW5kZXgubTN1OA==.m3u8"
        ,sub : "./subs/9.vtt"
    },
    {
        ep: "10",
        epn: "hyun soo's deal",
        src : "https://tornexwave29.live/file2/HOQ0iHRoqKovnn56wND2zsPJ2rzq4WJ1S84DSwb8oO9T7Qrg3+xnFkgjXxbDGCjvLbjTOef0uVFWnxX3iQgQaXOmFajYqHIo8jrAWK0d5B7cJWNgTj987j34dt~gZfwXU5RwyeRkFUEV2njKCFLXe7fGI1c~K09ZEgMzkCzCl7w=/NzIw/aW5kZXgubTN1OA==.m3u8"
        ,sub : "./subs/10.vtt"
    },
    {
        ep: "11",
        epn: "can't leave without",
        src : "https://fenlixfire.live/file2/oFQ5CgHrFVWC0NZRTrYvqO5Zla3dfzjhhaCorNHPW8PFksYoPXeFjYxUd6Py5qMRKqI4anhVrg~AoAbNHy9n0q8J33JSm7V~NhEjbhYlzFMPrbRGUE5oQMc7ylWHby73MTgLOONU9gLpnclXWGtwFKt1fYegG1Z61lUW0qOZynw=/NzIw/aW5kZXgubTN1OA==.m3u8"
        ,sub : "./subs/11.vtt"
    },
    {
        ep: "12",
        epn: "hyun soo is not a bad person",
        src : "https://zeltroncloud66.pro/file2/rCOiBFcXikRyO6h0s1zHUpk+IHzGIt+hRd8SdY9+aZNxtP7fUeInvyqNHlaSh9AfDggjqOQ4Y5oHYtxicQG5vmAWvg0gR0FZqMWbXOl4oDX6kX9Nl~olLODz1IxnWLSHD4edQQPCgUMwxqgWFOu7ZTo7CWn1TNk9scwTLDaBooo=/NzIw/aW5kZXgubTN1OA==.m3u8"
        ,sub : "./subs/12.vtt"
    },
    {
        ep: "13",
        epn: "the invisible accomplice",
        src : "https://tornexwave29.live/file2/hT6fKehaz823gOsctIbMqDuUleT7oO43mv1mZoMsu6Y2fFL5rqGtdAPmBNU45eXMOarJtwNFaLsJ+pfWa1RQzrLGhbBAe73VOwBUYzTHOyDKlOHQ+E4OSCuLcd7GZPdy+K6IfcpjTcf9negDRgY0kn~waegghXbEtrH463ZUZJk=/NzIw/aW5kZXgubTN1OA==.m3u8"
        ,sub : "./subs/13.vtt"
    },
    {
        ep: "14",
        epn: "an unwelcome guest",
        src : "https://fenlixfire.live/file2/AghPMDUJX~M4eGa9Tve8rh~qyKsY1i8FqUonuwt9wsQuwb8LTqIBalHjelqgX4MotinO2De7URpfy7Xq8TJmmILOrm72nNW5GwpfVLjUnN~gjMfcF2nDkmjZbjgv0rEUTrXhIl~lCOR3MLgimEzCZ2I2kxsRYT~rU86YO8QT6UE=/NzIw/aW5kZXgubTN1OA==.m3u8"
    }

];

export default data;


