// import React, { useState } from 'react';
// import { FullScreen, useFullScreenHandle } from "react-full-screen";
// import ReactPlayer from 'react-player';
// import data from './data.js';

// function CallFS({ url, handle }) {
//   return (
//     <FullScreen handle={handle}>
//       <ReactPlayer
//         controls={true}
//         className="player"
//         height="100%"
//         width="100%"
//         url={url}
//       />
//     </FullScreen>
//   );
// }

// function EpisodeDiv({ ep, epn, src, onEpisodeClick }) {
//   return (
//     <div
//       onClick={() => onEpisodeClick(src)} // Trigger fullscreen with URL
//       style={{
//         width: "50vw",
//         backgroundColor: "grey",
//         gap: "10px",
//         textDecoration: "none",
//         display: "flex",
//         flexDirection: "row",
//         justifyContent: "center",
//         alignItems: "center",
//         cursor: "pointer",
//       }}
//     >
//       <h1>{ep}</h1>
//       <h2>{epn}</h2>
//     </div>
//   );
// }

// export default function Test() {
//   const [currentUrl, setCurrentUrl] = useState(null);
//   const handle = useFullScreenHandle(); // Move handle inside component

//   const handleEpisodeClick = (url) => {
//     setCurrentUrl(url);  // Set the video URL
//     handle.enter();       // Enter fullscreen
//   };

//   return (
//     <div style={{ gap: "25px", display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center" }}>
//       {data.map((episode, index) => (
//         <EpisodeDiv
//           key={index}
//           ep={episode.ep}
//           epn={episode.epn}
//           src={episode.src}
//           onEpisodeClick={handleEpisodeClick}
//         />
//       ))}
//       {currentUrl && <CallFS url={currentUrl} handle={handle} />} {/* Pass handle to player */}
//     </div>
//   );
// }




// import React, {useCallback} from 'react';
// import data from './data.js';
// import { FullScreen, useFullScreenHandle } from "react-full-screen";
// import ReactPlayer from 'react-player';
// import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
// import Player from './player.js'


// function CallFS(handle, url) {
//   handle.enter
//   return(
//     <FullScreen handle={handle}>
//       <button onClick={() => handle.exit()} style={{zIndex:"10", cursor: "pointer", position: "absolute", margin: "50px 50px"}}></button>
//       <ReactPlayer 
//         controls={true}
//           className="player" 
//           height="100%" width="100%"
//           url={url}
      
//         />
//       </FullScreen>
//   );
// }
// function EpisodeDiv(props) {
  
  
//   return(
//     <Link onClick={CallFS(props.src)} key = {props.ep} style={{ width : "50vw", backgroundColor:"grey", gap:"10px", textDecoration:"none", display:"flex", flexDirection:"row", justifyContent:"center", alignItems:"center"}}>
      
//       <h1>{props.ep}</h1>
//       <h2>{props.epn}</h2>
//     </Link>
//   );
// }
// export default function Test() {
//   const handle = useFullScreenHandle();
//   return (<div style={{gap : "25px", display:"flex", flexDirection:"column", justifyContent:"center", alignItems:"center"}}>
//     {data.map(EpisodeDiv)}
//   </div>
    
//   );
// }




import React, { useState, useRef } from 'react';
import { FullScreen, useFullScreenHandle } from "react-full-screen";
import ReactPlayer from 'react-player';
import data from './data.js';

function CallFS({ url, handle }) {
  const playerRef = useRef(null); // Create a ref for ReactPlayer

  const handleExit = () => {
    handle.exit(); // Exit fullscreen
    if (playerRef.current) {
      playerRef.current.seekTo(0);  // Optional: Reset video to the beginning
      playerRef.current.getInternalPlayer().pause();  // Pause the video
    }
  };

  return (
    <FullScreen handle={handle}>
      <button
        onClick={handleExit} // Call the custom exit function
        style={{ position: "absolute", margin: "20px", zIndex: "10" }}
      >
        Exit
      </button>
      <ReactPlayer
        ref={playerRef} // Attach the ref to the player
        controls={true}
        height="100%"
        width="100%"
        url={url}
      />
    </FullScreen>
  );
}

function EpisodeDiv({ ep, epn, src, onEpisodeClick }) {
  return (
    <div
      onClick={() => onEpisodeClick(src)} // Trigger fullscreen with URL
      style={{
        width: "50vw",
        backgroundColor: "grey",
        gap: "10px",
        textDecoration: "none",
        display: "flex",
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        cursor: "pointer",
      }}
    >
      <h1>{ep}</h1>
      <h2>{epn}</h2>
    </div>
  );
}

export default function Test() {
  const [currentUrl, setCurrentUrl] = useState("https://droxonwave.site/file2/m~yjTrxD9jSgeFrHJbx9qTsq3Nq~zE7BU2y5dJ+qqlxe3JcQGBxsBnkiYZwR4qi8Ofq9DOp01xM2vOKdHP+Y57~qogDwsFchlFxR0dwLsbkRDDNpGb~DvR8UF6dFeUCSwaDMd7qcqRnHDW6S8~+l8nf7bxIz+rsu4bYK5epCr7w=/NzIw/aW5kZXgubTN1OA==.m3u8"); // Initially no URL loaded
  const handle = useFullScreenHandle(); // Create fullscreen handle

  const handleEpisodeClick = (url) => {
    setCurrentUrl(url); // Set the video URL
    handle.enter();     // Enter fullscreen mode
  };

  return (
    <div style={{ gap: "25px", position: "relative", display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center" }}>
      {data.map((episode, index) => (
        <EpisodeDiv
          key={index}
          ep={episode.ep}
          epn={episode.epn}
          src={episode.src}
          onEpisodeClick={handleEpisodeClick}
        />
      ))}

      {currentUrl && <div style={{position:"absolute", top:"0px", left:"200vw", opacity: "0", zIndex:"-10"}}><CallFS url={currentUrl} handle={handle} /></div>}
    </div>
  );
}
