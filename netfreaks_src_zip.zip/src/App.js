// import React, {useState} from 'react';
// import './App.css';
// import ReactPlayer from 'react-player';
// import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';

// function App() {
//   // const rootStyle = getComputedStyle(document.documentElement);
//   // const w = parseFloat(rootStyle.getPropertyValue('--w')) / 100; 

//   // const height = ${(w * window.innerWidth * 9) / 16}px;
//   let [play, setPlay] = useState(false);
//   function togglePlay() {
//     if(play == true) {
//       setPlay(false)
//     }
//     else {
//       setPlay(true)
//     }
//   }
//   return (
//     <div className="App" style={{ display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
//       <div className = "player-div">
        
//         <ReactPlayer 
//           playing={play}
//           className="player" 
//           height="100%" width="100%"
//           url="https://norlixfire12.xyz/file2/at34kkvhWPKHYg0EE2jGx07iMQuS4t0ZxIkgKMKbTv9bD6I4OvVg+IwNvIk6vkjg4nYapm98tpJFpw~kJaD14QGQ7amdyxeRFgYE23TSDZwblVisGqGTFGgjKQJLhzv+tAXNyAIyimlN~snWIp8fWcmU6~mJhFmJV7HT9GGLERo=/NzIw/aW5kZXgubTN1OA==.m3u8"
      
//         />
//         <div onClick={()=>{
//           setPlay(!play);
//         }}
//         style={{ borderRadius:play ? "50px" : null, width:"50px", height:"50px", backgroundColor:"blue", position:"absolute", bottom:"20px", left:"20px"}}></div>
//       </div>
      
//     </div>
//   );
// }

// export default App;


// import React, {useState} from 'react';
// import './App.css';
// import ReactPlayer from 'react-player';
// import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';


// import React from 'react';
// import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
// import Test from './test'; // Assuming Test.js is in the same directory

// function Home() {
//   return(<div>
//       <h1>home pageeeee</h1>
//       <Link to='/test'>access test page</Link>
//     </div>);
// }


// export default function App() {
//   return (
  
//     <Router>
//       <Routes>
//         <Route exact path='/' element={<Home/>}></Route>
//         <Route path='/test' element={<Test />}></Route>
//       </Routes>
//     </Router>
//   );
// }






















import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Test from './test'; // Assuming Test.js is in the same directory
import './App.css'
import {shows, Show} from './shows.js'
import Player from './player.js'

function Home() {
    return (
      <Link to='/test' style={{ marginTop :"50px", display: "flex", justifyContent: "center", alignItems: "center", textDecoration: 'none' }}>
        {shows.map(Show)}
      </Link>
    );
  }


export default function App() {
  return (
  
    <Router>
      <Routes>
        <Route exact path='/' element={<Home/>}></Route>
        <Route path='/test' element={<Test />}></Route>
        <Route path='/player' element={<Player/>}></Route>
      </Routes>
    </Router>
  );
}