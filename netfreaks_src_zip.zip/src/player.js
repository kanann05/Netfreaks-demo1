// import React, {useState} from 'react';
// import './App.css';
// import ReactPlayer from 'react-player';
// import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
// import { FullScreen, useFullScreenHandle } from "react-full-screen";

// function App() {
//   // const rootStyle = getComputedStyle(document.documentElement);
//   // const w = parseFloat(rootStyle.getPropertyValue('--w')) / 100; 

//   // const height = ${(w * window.innerWidth * 9) / 16}px;
//   let [play, setPlay] = useState(false);
//   function togglePlay() {
//     if(play == true) {
//       setPlay(false)
//     }
//     else {
//       setPlay(true)
//     }
//   }
//   return (
//     <div className="App" style={{ display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
//       <div className = "player-div">
        
        // <ReactPlayer 
        //   playing={play}
        //   className="player" 
        //   height="100%" width="100%"
        //   url="https://norlixfire12.xyz/file2/at34kkvhWPKHYg0EE2jGx07iMQuS4t0ZxIkgKMKbTv9bD6I4OvVg+IwNvIk6vkjg4nYapm98tpJFpw~kJaD14QGQ7amdyxeRFgYE23TSDZwblVisGqGTFGgjKQJLhzv+tAXNyAIyimlN~snWIp8fWcmU6~mJhFmJV7HT9GGLERo=/NzIw/aW5kZXgubTN1OA==.m3u8"
      
        // />
//         <div onClick={()=>{
//           setPlay(!play);
//         }}
//         style={{ borderRadius:play ? "50px" : null, width:"50px", height:"50px", backgroundColor:"blue", position:"absolute", bottom:"20px", left:"20px"}}></div>
//       </div>
//       <button onClick={useFullScreenHandle}>fullscreen</button>
//     </div>
//   );
// }

// export default App;







// import React, {useCallback} from 'react';
// import { FullScreen, useFullScreenHandle } from "react-full-screen";
// import ReactPlayer from 'react-player';
// function Player() {
//   const handle = useFullScreenHandle();
    
//   return (
//     <div>
//       <button className='but' style={{cursor:"pointer"}} onClick={handle.enter}>
//         Enter fullscreen
//       </button>
//       <FullScreen handle={handle}>
//       <button onClick={() => handle.exit()} style={{zIndex:"10", cursor: "pointer", position: "absolute", margin: "50px 50px"}}>
//   hallo
// </button>

//       <ReactPlayer 
//         controls={true}
//           className="player" 
//           height="100%" width="100%"
//           url="https://norlixfire12.xyz/file2/at34kkvhWPKHYg0EE2jGx07iMQuS4t0ZxIkgKMKbTv9bD6I4OvVg+IwNvIk6vkjg4nYapm98tpJFpw~kJaD14QGQ7amdyxeRFgYE23TSDZwblVisGqGTFGgjKQJLhzv+tAXNyAIyimlN~snWIp8fWcmU6~mJhFmJV7HT9GGLERo=/NzIw/aW5kZXgubTN1OA==.m3u8"
      
//         />
//       </FullScreen>
//     </div>
//   );
// }

// export default Player;






import React, {useCallback} from 'react';
import { FullScreen, useFullScreenHandle } from "react-full-screen";
import ReactPlayer from 'react-player';
function Player(props) {
  const handle = useFullScreenHandle();
    
  return (
    <div>
      <button className='but' style={{cursor:"pointer"}} onClick={handle.enter}>
        Enter fullscreen
      </button>
      <FullScreen handle={handle}>
      <button onClick={() => handle.exit()} style={{zIndex:"10", cursor: "pointer", position: "absolute", margin: "50px 50px"}}>
  hallo
</button>

      <ReactPlayer 
        controls={true}
          className="player" 
          height="100%" width="100%"
          url={props.url}
      
        />
      </FullScreen>
    </div>
  );
}

export default Player;