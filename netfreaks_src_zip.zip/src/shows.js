// shows.js
export const shows = [{
    show: "flower of evil",
    eps: "./data.js",
    show_img: "https://i0.wp.com/cameronthompsontyo.com/wp-content/uploads/2023/08/c2a65edf069fb96c2b8a9399d8b13e49411bee672ea6fd7a97392e7fb3bdaec7.jpeg?resize=1200%2C900&ssl=1"
  }];
  
  export function Show(props) {
    return (
      <div style={{ height: "400px", width: "400px" }}>
        <img src={props.show_img} style={{ width: "300px", aspectRatio: "1/1", objectFit: "cover" }} />
        <h1 style={{textDecoration:"none"}}>{props.show}</h1>
      </div>
    );
  }
  